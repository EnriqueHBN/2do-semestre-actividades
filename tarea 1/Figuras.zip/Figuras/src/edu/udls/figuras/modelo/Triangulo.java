/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.udls.figuras.modelo;

/**
 *
 * @author kicay
 */
public class Triangulo extends Figura {

    //atributos
    private float base;
    private float lado2;
    private float lado3;
    private int tipo;

    //Constructor vacio
    public Triangulo() {
    }

    //Constructor Lleno
    public Triangulo(float base, float lado2, float lado3, int tipo) {
        this.base = base;
        this.lado2 = lado2;
        this.lado3 = lado3;
        this.tipo = tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getBase() {
        return base;
    }

    public void setLado2(float lado2) {
        this.lado2 = lado2;
    }

    public float getLado2() {
        return lado2;
    }

    public void setLado3(float lado3) {
        this.lado3 = lado3;
    }

    public float getLado3() {
        return lado3;
    }

    public double getArea(float base, float lado2, float lado3, int tipo) {
        if (tipo == 2 && tipo == 3) {
            double altura = Math.sqrt((Math.pow(lado2, 2) - (Math.pow(base, 2) / 4)));
            double area = (base * altura) / 2;
            return area;
        } else {
            return ((Math.sqrt(3)) / 4) * Math.pow(base, 2);
        }
    }

    public double getPerimetro(float base, float lado2, float lado3) {
        return base + lado2 + lado3;
    }

    @Override
    public String toString() {
        return "Triangulo { lado1 =" + this.base + ", lado2 = " + this.lado2 + ", lado3 = " + this.lado3 + "}.";
    }
}
