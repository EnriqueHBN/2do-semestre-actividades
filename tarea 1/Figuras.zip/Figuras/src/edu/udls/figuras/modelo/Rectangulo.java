/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.udls.figuras.modelo;

/**
 *
 * @author kicay
 */
public class Rectangulo extends Figura {

    float base;
    float altura;

    public Rectangulo() {
    }

    public Rectangulo(float base, float altura) {
        this.base = base;
        this.altura = altura;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public float getBase(float base) {
        return this.base = base;
    }

    public float getAltura(float Altura) {
        return this.altura = Altura;
    }

    @Override
    public String toString() {
        return "Rectangulo : (altura:" + this.altura
                + " , base: " + this.base + ")";
    }

    public float getArea() {
        return this.base * this.altura;
    }

    public float getPerimetro() {
        return (this.altura * 2) + (this.altura * 2);
    }

}
