/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.udls.figuras.modelo;

/**
 *
 * @author kicay
 */
public class Circulo extends Figura {

    float radio;

    public Circulo() {
    }

    public Circulo(float base, float altura) {
        this.radio = base;
    }

    /**
     *
     * @param radio
     */
    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getRadio(float Radio) {
        return this.radio = Radio;
    }

    @Override
    public String toString() {
        return "Circulo : (radio:" + this.radio + ")";
    }

    public float getArea() {
        float getArea = (float) (Math.pow(this.radio, 2) * Math.PI);
        return getArea;
    }

    public float getPerimetro() {
        float getPerimetro = (float) ((this.radio * 2) * Math.PI);
        return getPerimetro;
    }

}
