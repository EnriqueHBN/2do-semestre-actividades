/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.udls.figuras.modelo;

/**
 *
 * @author kicay
 */
public class Poligono extends Figura {

    private float lados;
    private float apotema;
    private int tipo;

    public Poligono() {
    }

    public Poligono(float lados, float apotema, int tipo) {
        this.lados = lados;
        this.apotema = apotema;
        this.tipo = tipo;
    }

    public void setLados(float lados) {
        this.lados = lados;
    }

    public float getLados() {
        return lados;
    }

    public void setApotema(float apotema) {
        this.apotema = apotema;
    }

    public float getApotema() {
        return apotema;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getTipo() {
        return tipo;
    }

    public static float getPerimetro(float lados, float tipo) {
        return lados * tipo;
    }

    public float getArea(float apotema, float lados, int tipo) {
        float perimetro = getPerimetro(lados, tipo);
        return (perimetro * apotema) / 2;
    }

    @Override
    public String toString() {
        return "Poligono { lados =" + lados + ", apotema = " + apotema + ", tipo = " + tipo + " }.";
    }
}
