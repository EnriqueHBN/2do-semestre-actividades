/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.udls.figuras.vista;

import edu.udls.figuras.modelo.Rectangulo;
import javax.swing.JOptionPane;
import edu.udls.figuras.modelo.Circulo;
import edu.udls.figuras.modelo.Triangulo;
import edu.udls.figuras.modelo.Poligono;

/**
 *
 * @author Alegr
 */
public class Principal {

    public static void main(String[] x) {
        //manipularRectangulo()
        manipularCirculo();
    }

    public static void manipularRectangulo() {

        String nombre = JOptionPane.showInputDialog("Ingresa el nombre");   
        float base = Float.parseFloat(JOptionPane.showInputDialog("Ingresa la Base"));

        float altura = Float.parseFloat(JOptionPane.showInputDialog("Ingresa la altura"));



        Rectangulo objRectangulo = new Rectangulo();
        objRectangulo.setAltura(altura);
        objRectangulo.setBase(base);
        objRectangulo.setNombre(nombre);

        JOptionPane.showMessageDialog(null, objRectangulo.toString());
        JOptionPane.showMessageDialog(null, "El area es:" + objRectangulo.getArea());
        JOptionPane.showMessageDialog(null, "El perimetro es:" + objRectangulo.getPerimetro());
    }

    public static void manipularCirculo() {

        String nombre = JOptionPane.showInputDialog("Ingresa el nombre");
        float radio = Float.parseFloat(JOptionPane.showInputDialog("Ingresa el radio"));

        

        Circulo objCirculo = new Circulo();
        objCirculo.setRadio(radio);
        objCirculo.setNombre(nombre);
        JOptionPane.showMessageDialog(null, objCirculo.toString());
        JOptionPane.showMessageDialog(null, "El area es:" + objCirculo.getArea());
        JOptionPane.showMessageDialog(null, "El perimetro es:" + objCirculo.getPerimetro());

    }

    public static void manipularTriangulo() {
             String nombre = (JOptionPane.showInputDialog("Ingresa el nombre"));
        int tipo = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el tipo de lado"));
        float base = Float.parseFloat(JOptionPane.showInputDialog("Ingresa la base"));
        float lado2 = base;
        float lado3 = base;
   
        Triangulo objTriangulo = new Triangulo();
        objTriangulo.setBase(base);
        objTriangulo.setLado2(lado2);
        objTriangulo.setLado3(lado3);
        JOptionPane.showMessageDialog(null, "El triangulo " + nombre + objTriangulo.toString());
        JOptionPane.showMessageDialog(null, "El area es " + objTriangulo.getArea(base, lado2, lado3, tipo));
        JOptionPane.showMessageDialog(null, "El perimetro es " + objTriangulo.getPerimetro(base, lado2, lado3));
    }

    public static void manipularPoligono() {
                String nombre = (JOptionPane.showInputDialog("Ingresa el nombre"));
        float lados = Float.parseFloat(JOptionPane.showInputDialog("Ingresa el valor de los lados"));
        float apotema = Float.parseFloat(JOptionPane.showInputDialog("Ingresa el valor de la apotema"));
        int tipo = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el tipo de poligono"));

        Poligono objPoligono = new Poligono();
        objPoligono.setLados(lados);
        objPoligono.setApotema(apotema);
        objPoligono.setTipo(tipo);
        JOptionPane.showMessageDialog(null, "El Poligono " + nombre + objPoligono.toString());
        JOptionPane.showMessageDialog(null, "El area es " + objPoligono.getArea(apotema, lados, tipo));
        JOptionPane.showMessageDialog(null, "El perimetro es " + objPoligono.getPerimetro(lados, tipo));
    }
}
